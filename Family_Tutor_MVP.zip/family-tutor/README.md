# Family Tutor 2 — PT2 + Jarvis

A working source package for the family tutor, updated to the agreed shared Google login and PIN-free profiles. **This package is not a live deployment.**

## Included

- One allowlisted Google account, then Parent or either child's profile. Names/grades come from real imported records. Profile selection is independent on each browser/device, with no PIN. Anyone using the shared account may choose Parent, as requested.
- Jarvis in a right-hand assistant panel: Chat/Voice tabs, amber orb, microphone, mute, end, language selection and transcript. Voice input uses browser speech recognition when supported; replies use browser speech synthesis. Chat remains available where speech is unsupported.
- 41 PT2 portions from the two supplied term-wise PDFs, with source-page references and explicit exclusions/unknown scope. Exam dates remain **Not announced**.
- An editable routine based on the supplied examples, with Saturday madrasa 08:30–13:00 and three 70-minute blocks on Saturday/Sunday. Planner tests verify 180 net study minutes each weekend day for both grades, excluding breaks.
- Daily portion checklists, needs-help flags, distinct practice evidence, active-time study sessions and separately labelled reported offline study.
- A server-timed heartbeat and one active timer per child to prevent overlapping-device double counting. Hidden, paused or idle tabs do not keep accruing study time. Time is an activity estimate, not proof of attention or understanding.
- School-file uploads: PDF, PNG, JPEG, WebP or UTF-8 text, up to 2 MB. PDF.js extracts readable PDF text in the browser; the family reviews the subject/portion/text before the material is marked ready. Scanned/image pages need pasted readable text; automatic OCR is not connected.
- Private school-file storage, content hashes for duplicate detection, existing Drive-file identity support, and prompts to check for new portal materials.
- MCQs, fill-in-the-blanks, matching and short-answer practice. MCQ/blank/matching keys are checked in the database; short answers wait for parent review and are excluded from accuracy while pending.
- Coordinated assessment-wide weekly planning, parent controls, progress views, saved tutor conversations and a migration tool for old Sheets exports.

## Try it

Open `PREVIEW.html` in a browser. It is a self-contained **read-only preview with fictional students and progress**. The PT2 portion titles reflect the supplied school documents. Use **Switch profile**, **Portions**, **Study log**, **Materials**, **Practice**, and the **Jarvis** button.

For the full application, with Node.js 22 or later:

```bash
npm run dev
```

Open http://localhost:3000. Real Google login and persistence require the setup in `SETUP.md`.

There is no npm install/build dependency. Vendored PDF.js 5.6.205 legacy-browser modules are under `public/vendor/`, with the Apache license. The app uses HTML/CSS/JavaScript and a Node.js API on Vercel, with Supabase Auth/Postgres/Storage.

## Checks

```bash
npm run check
npm test
```

`npm test` regenerates the standalone preview and runs the local tests. `BUILD_REPORT.txt` records final checks and what remains unverified. These tests do not replace live SQL/RLS, Google OAuth, storage and browser/microphone checks.

## What is still required

The Vercel and Supabase integrations were disabled in this workspace. No hosted account was configured, no real family database was migrated, and no live login/deployment was completed.

The AI connection remains disabled. The child-directed Gemini Developer API restriction discussed in the conversation remains unresolved. The package includes a dormant Gemini development adapter, not a live Gemini tutor for children. A suitably permitted AI provider/gateway is required for live Jarvis answers and generated practice. Existing parent-assigned practice, checklists and planning can operate without it after database setup.

No approved host browser was available, so visual/mobile/microphone QA is still required. HTML/state/preview/HTTP checks were performed; they are not browser layout or speech tests.

Start with **SETUP.md, Step 1**. Old n8n workflows/source files are not changed.
